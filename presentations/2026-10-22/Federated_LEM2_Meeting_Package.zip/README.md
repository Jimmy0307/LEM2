# Federated LEM2 研究會議簡報

依 `LEM2_MEETING_BACKUP_2026-10-22.zip` 的 PPT prompt 製作。

- `Federated_LEM2_Meeting_Deck.pptx`：15 頁繁體中文、16:9；文字、圖形、流程與結果表可編輯，每頁含 speaker notes。
- `Federated_LEM2_Meeting_Deck.pdf`：版面固定的預覽與分享版。
- `Federated_LEM2_System_Flow.svg/.png`：全系統架構圖。
- `Federated_LEM2_Conflict_Flow.svg/.png`：推論衝突決策圖。
- `Standard_vs_Global_Strength.svg/.png`：support 加總與 unique-object 聯集對比。
- `speaker_notes.md`：逐頁 30–60 秒講稿及五題教授問答。
- `source_mapping.md`：逐頁檔案、章節、文獻與證據邊界。
- `content_lock_summary.md`：一頁式內容鎖定摘要與素材差異處理記錄。
- `frozen_uci3_balanced_accuracy.csv`：第 12 頁的 48 個鎖定 BA 數值。
- `verification_report.json`：15 頁、15 組內嵌講稿、48 數值、檔案校驗與版面檢查結果。
- `deck_contact_sheet.jpg`：全份簡報縮圖。

數據、公式與研究結論以鎖定事實為準，未重新訓練 UCI3，也未更新 GitHub PR 狀態。備份 research CI 的 105 tests 與本次 main 環境的 100 tests 分開標示。原始研究檔案未改動。

字型：Noto Sans CJK TC。PDF 已固定字型顯示，若 PowerPoint 未安裝該字型，可安裝 Noto Sans CJK TC 或選擇適合的繁體中文字型後檢查換行。
